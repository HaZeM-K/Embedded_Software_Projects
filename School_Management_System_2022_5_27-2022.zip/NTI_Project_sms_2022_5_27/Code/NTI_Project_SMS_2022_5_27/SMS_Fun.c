#include "SMS_Header.h"




/*this function is for prompting the user and selecting operations*/
void Main_Menu()
{

    /*initialization*/
    usi chc = 0;
    Strct s;
    crt_Nd(&s);
    usi Mn_Lp = 1;

    printf("\n**********WELCOME**********\n");
    printf("\nThis program is a school management system\n");



    while(Mn_Lp)
    {


        /*prompt the user with selection info*/
        printf("\nEnter 1 to insert a new student\n");
        printf("\nEnter 2 to delete an existing student\n");
        printf("\nEnter 3 to view the list of students in the system\n");
        printf("\nEnter 4 to edit a student's information\n");
        printf("\nEnter 5 to rank students according to score\n");
        printf("\nEnter 6 to edit a student's score\n");
        printf("\nEnter 7 to know the number of students\n");
        printf("\nEnter 8 to view unsorted list of students\n");
        printf("\nEnter 0 to end the program\n\n\n\n");


        /*take selection from the user*/
        printf("\n\nYour choice:\t");
        scanf("%hd", &chc);
        fflush(stdin);


        /*selecting operation*/
        switch(chc)
        {
            case 1:

                Nu_Stdnt(&s);
                break;


            case 2:
                Dlt_Stdnt(&s);
                break;

            case 3:
                Stdnt_Lst(&s);
                break;

            case 4:
                Stdnt_Edt(&s);
                break;

            case 5:
                Rnk_Stdnt(&s);
                break;

            case 6:
                Stdnt_Scr(&s);
                break;

            case 7:
                Stdnts_Nmbr(&s);
                break;

            case 8:
                Vu_Stdnts(&s);
                break;

            case 0:
                Mn_Lp = 0;
                break;

            default:
                printf("\nPlease enter a valid choice number\n");
                break;

        }
        /* test the info inside the nodes*/

    }


}/*End of Main_Menu function*/








void crt_Nd(Strct *ps)
{
    /*to create structure in the stack and use it*/
    ps->tp = NULL;
    ps->sz = 0;

}







void Nu_Stdnt(Strct *ps)
{
    /*new student function*/
    StdntNd *pn = (StdntNd *)malloc(sizeof(StdntNd));
    printf("\nEnter student Name:\t");
    gets(pn->stdnt_Nm);
    fflush(stdin);

    printf("\nEnter student id:\t");
    scanf("%ld", &pn->stdnt_Id);
    fflush(stdin);

    printf("\nEnter student DOB:\t");
    scanf("%s", pn->stdnt_Dob);
    fflush(stdin);

    printf("\nEnter the student address:\t");
    gets(pn->stdnt_Adrs);
    fflush(stdin);

    printf("\nEnter the student phone number:\t");
    scanf("%s", pn->stdnt_Phn);
    fflush(stdin);

    printf("\nEnter the student score:\t");
    scanf("%hd", &pn->stdnt_scr);
    fflush(stdin);
    printf("\n\n\n\n");
    pn->nxt = ps->tp;
    ps->tp = pn;
    ps->sz++;

}/*End of Nu_Stdnt function*/











void Dlt_Stdnt(Strct *ps)
{
    /*delete existing student*/
    usi i = 0;
    uli srsh_id;
    usi plc = 1;
    usi srsh_Dn = 0;
    StdntNd *slct = ps->tp;
    StdntNd *tmp1;
    StdntNd *tmp2 = ps->tp;


    printf("\nEnter the id of the student:\t");
    scanf("%ld", &srsh_id);

    /*search sequence*/
    while(i < (ps->sz) && srsh_Dn == 0)
    {
        if(srsh_id == slct->stdnt_Id)
        {
            srsh_Dn = 1;
        }
        else
        {
            slct = slct->nxt;
            plc++;
        }
    }

        if(plc == 1)
        {
            StdntNd *pn = ps->tp;
            ps->tp = ps->tp->nxt;
            free(pn);
            ps->sz--;
        }
        else
        {


            if (plc <= (ps->sz))
            {

                while(i < (plc - 2))
                {
                    tmp2 = tmp2->nxt;
                    i++;
                }

                tmp1 = tmp2->nxt;
                tmp2->nxt = tmp1->nxt;
                free(tmp1);
                ps->sz--;
            }
            else
            {
                printf("\n\n\nSomething went wrong!!!\n\n\n");
            }

            if(srsh_Dn == 0)
            {
                printf("\n\nCan't find this Id. Please make sure you're entering the right id.\n\n");
            }

        }
}/*End of Dlt_Stdnt function*/











void Stdnt_Lst(Strct *ps)
{
    /*view students information sorted(ascending) according to name*/
    /*initialization*/
    StdntNd *f = NULL;
    StdntNd *tmp = NULL;
    StdntNd *ptmp = NULL;
    StdntNd *tmpvu = NULL;
    usi i = 0;


    /*sorting phase*/
    while(i < (ps->sz))
    {


        if(strcmp((ps->tp->stdnt_Nm), (ps->tp->nxt->stdnt_Nm)) > 0)
        {
            f = ps->tp;
            ps->tp = f->nxt;
            f->nxt = f->nxt->nxt;
            ps->tp->nxt = f;
        }


        tmp = ps->tp;
        ptmp = tmp->nxt;


        while(ptmp->nxt != NULL)
        {
            if(strcmp((ptmp->stdnt_Nm), (ptmp->nxt->stdnt_Nm)) <= 0 )
            {
                ptmp = ptmp->nxt;
                tmp = tmp->nxt;
            }
            else
            {
                tmp->nxt = ptmp->nxt;
                ptmp->nxt = ptmp->nxt->nxt;
                tmp->nxt->nxt = ptmp;
                tmp = tmp->nxt;

            }

        }

        i++;

    }

    /*viewing phase*/
    tmpvu = ps->tp;


    printf("\nName\t\t\t\tID\t   DOB\t       Address\t\t\t\tPhone\t\tScore\n");

    while(tmpvu != NULL)
   {

       printf("\n%-30s  ", tmpvu->stdnt_Nm);
       printf("%-10ld ", tmpvu->stdnt_Id);
       printf("%-10s  ", tmpvu->stdnt_Dob);
       printf("%-31s  ", tmpvu->stdnt_Adrs);
       printf("%-14s  ", tmpvu->stdnt_Phn);
       printf("%-5hd ", tmpvu->stdnt_scr);
       printf("\n*************************************************************************************************************");
       tmpvu = tmpvu->nxt;

    }
}













void Stdnt_Edt(Strct *ps)
{
    /*edit the information of students*/

    /*initialization*/
    usi srsh_Dn = 0;
    usi i = 0;
    uli srsh_id;
    usi edt_chc;
    StdntNd *tmp = ps->tp;

    /*search-by factor*/
    printf("\nEnter the id of the student:\t");
    scanf("%ld", &srsh_id);

    /*search sequence*/
    while(i < (ps->sz) && srsh_Dn == 0)
    {

        /*check if this node is the required node*/
        if(srsh_id == tmp->stdnt_Id)
        {
            /*display old information*/
            printf("\n\nCurrent Name is: %s\n\n", tmp->stdnt_Nm);
            printf("\n\nCurrent ID is: %ld\n\n", tmp->stdnt_Id);
            printf("\n\nCurrent Date of birth is: %s\n\n", tmp->stdnt_Dob);
            printf("\n\nCurrent address is: %s\n\n", tmp->stdnt_Adrs);
            printf("\n\nCurrent phone number is is: %s\n\n", tmp->stdnt_Phn);
            printf("\n******************************************\n");

            /*ask the user which info he/she wants to edit*/
            printf("\n\n\n");
            printf("\nWhich information you want to edit:\t");
            printf("\n\nEnter 1 to edit name\n");
            printf("\nEnter 2 to edit ID\n");
            printf("\nEnter 3 to edit Date of birth\n");
            printf("\nEnter 4 to edit Address\n");
            printf("\nEnter 5 to edit Phone number\n");
            printf("\nEnter 0 to cancel\n\n");
            printf("\nYour choice:\t");
            scanf("%hd", &edt_chc);
            printf("\n******************************************\n");

            /*execute operation based on choice*/
            switch(edt_chc)
            {
                case 1:
                    printf("\nEnter the new name of the student:\t");
                    scanf("%s", tmp->stdnt_Nm);
                    fflush(stdin);
                    break;

                case 2:
                    printf("\nEnter the new ID of the student:\t");
                    scanf("%ld", &tmp->stdnt_Id);
                    fflush(stdin);
                    break;

                case 3:
                    printf("\nEnter the new DOB of the student:\t");
                    scanf("%s", tmp->stdnt_Dob);
                    fflush(stdin);
                    break;

                case 4:
                    printf("\nEnter the new Address of the student:\t");
                    scanf("%s", tmp->stdnt_Adrs);
                    fflush(stdin);
                    break;

                case 5:
                    printf("\nEnter the new phone number of the student:\t");
                    scanf("%s", tmp->stdnt_Phn);
                    fflush(stdin);
                    break;


                case 0:
                    break;

                default:
                    /*no action here*/
                    break;

            }

            /*now exit from the loop*/
            srsh_Dn = 1;
        }
        else
        {
            /*make the tmp pointer moves to the next node*/
            tmp = tmp->nxt;

        }

        i++;


    }

    if(srsh_Dn == 0)
    {
        printf("\nStudent is not found. Make sure you've entered a valid ID\n");
    }

    if(srsh_Dn == 1)
    {


        printf("\n\n\n\n\n\n");
        printf("\n\nInformation after editing\n\n\n");
        printf("The name is: %s\n\n\n", tmp->stdnt_Nm);
        printf("The id of the student is: %ld\n\n\n", tmp->stdnt_Id);
        printf("The Date of birth of the student is: %s\n\n\n", tmp->stdnt_Dob);
        printf("The address of the student is: %s\n\n\n", tmp->stdnt_Adrs);
        printf("The phone of the student is: %s\n\n\n", tmp->stdnt_Phn);
        printf("\n******************************************\n");

    }

}










void Rnk_Stdnt(Strct *ps)
{
    /*rank students according to score*/

    /*initialization*/
    StdntNd *f = NULL;
    StdntNd *tmp = NULL;
    StdntNd *ptmp = NULL;
    StdntNd *tmpvu = NULL;
    usi i = 0;


    /*sorting phase*/
    while(i < (ps->sz))
    {


        if((ps->tp->stdnt_scr) < (ps->tp->nxt->stdnt_scr))
        {
            f = ps->tp;
            ps->tp = f->nxt;
            f->nxt = f->nxt->nxt;
            ps->tp->nxt = f;
        }


        tmp = ps->tp;
        ptmp = tmp->nxt;


        while(ptmp->nxt != NULL)
        {
            if((ptmp->stdnt_scr) >= (ptmp->nxt->stdnt_scr))
            {
                ptmp = ptmp->nxt;
                tmp = tmp->nxt;
            }
            else
            {
                tmp->nxt = ptmp->nxt;
                ptmp->nxt = ptmp->nxt->nxt;
                tmp->nxt->nxt = ptmp;
                tmp = tmp->nxt;

            }

        }

        i++;

    }


    /*viewing phase*/
    tmpvu = ps->tp;
    printf("\nName\t\t\t\tID\t   DOB\t       Address\t\t\t\tPhone\t\tScore\n");
    while(tmpvu != NULL)
   {

       printf("\n%-30s  ", tmpvu->stdnt_Nm);
       printf("%-10ld ", tmpvu->stdnt_Id);
       printf("%-10s  ", tmpvu->stdnt_Dob);
       printf("%-31s  ", tmpvu->stdnt_Adrs);
       printf("%-14s  ", tmpvu->stdnt_Phn);
       printf("%-5hd ", tmpvu->stdnt_scr);
       printf("\n*************************************************************************************************************");
       tmpvu = tmpvu->nxt;
   }

}





void Stdnt_Scr(Strct *ps)
{
    /*update the score of students*/
    StdntNd *tmpvu = ps->tp;
    usi ansr;

    while(tmpvu != NULL)
   {

       printf("The name is: %s\n\n\n", tmpvu->stdnt_Nm);
       printf("The id of the student is: %ld\n\n\n", tmpvu->stdnt_Id);
       printf("The current score of the student is: %hd\n\n\n\n", tmpvu->stdnt_scr);
       printf("Do you want to update the score of this student?\n\n(YES: 1) (NO: 0):\t");
       scanf("%hd", &ansr);

       if(ansr == 1)
       {
            printf("\nEnter the new Score of the student:\t");
            scanf("%hd", &tmpvu->stdnt_scr);
            fflush(stdin);
       }
       printf("\n******************************************\n");
       tmpvu = tmpvu->nxt;

    }


}






void Stdnts_Nmbr(Strct *ps)
{
   printf("\n\n\nThis system contains %ld students\n\n\n", ps->sz);
   printf("\n******************************************\n");


}












void Vu_Stdnts(Strct *ps)
{


   StdntNd *tmp = ps->tp;


   if(tmp == NULL)
   {
       printf("\n\n\nThis system is empty\n\n\n");
   }


    printf("\nName\t\t\t\tID\t   DOB\t       Address\t\t\t\tPhone\t\tScore\n");

    while(tmp != NULL)
   {

       printf("\n%-30s  ", tmp->stdnt_Nm);
       printf("%-10ld ", tmp->stdnt_Id);
       printf("%-10s  ", tmp->stdnt_Dob);
       printf("%-31s  ", tmp->stdnt_Adrs);
       printf("%-14s  ", tmp->stdnt_Phn);
       printf("%-5hd ", tmp->stdnt_scr);
       printf("\n*************************************************************************************************************");
       tmp = tmp->nxt;

    }

}
