#ifndef SMS_HEADER_H_INCLUDED
#define SMS_HEADER_H_INCLUDED



/*include standard libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>



/*macros and types replacements*/
#define usi unsigned short int
#define ssi signed short int
#define uli unsigned long int
#define sli signed long int
#define ch char
#define NAME_SIZE 60
#define DATE_SIZE 30
#define ADDRESS_SIZE 100
#define PHONE_NUMBER_SIZE 20





/*structures*/

/*Nodes structure*/
typedef struct stdntnd
{
    ch stdnt_Nm[NAME_SIZE];

    uli stdnt_Id;

    ch stdnt_Dob[DATE_SIZE];

    ch stdnt_Adrs[ADDRESS_SIZE];

    ch stdnt_Phn[PHONE_NUMBER_SIZE];

    usi stdnt_scr;

    struct stdntnd *nxt;

}StdntNd;


/*Top Pointer Structures*/
typedef struct top
{
    StdntNd *tp;
    uli sz;

}Strct;





/*global variables*/













/*prototypes*/
void Main_Menu();
void crt_Nd(Strct *ps);
void Nu_Stdnt(Strct *ps);
void Dlt_Stdnt(Strct *ps);
void Stdnt_Lst(Strct *ps);
void Stdnt_Edt(Strct *ps);
void Rnk_Stdnt(Strct *ps);
void Stdnt_Scr(Strct *ps);
void Vu_Stdnts(Strct *ps);
void Stdnts_Nmbr(Strct *ps);




#endif // SMS_HEADER_H_INCLUDED
