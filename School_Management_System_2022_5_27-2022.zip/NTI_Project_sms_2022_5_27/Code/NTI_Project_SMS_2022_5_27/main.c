/* Project Name: School Management System (NTI Version).

   Date: 27/05/2022


   Last update: 27/05/2022


   Author: Hazem Khaled Khabir

*/


/*include header file*/
#include "SMS_Header.h"




/*start the main function*/
int main()
{


    Main_Menu();



    return 0;
}
